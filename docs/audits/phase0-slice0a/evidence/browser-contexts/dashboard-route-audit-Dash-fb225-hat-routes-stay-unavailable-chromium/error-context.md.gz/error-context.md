# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: dashboard-route-audit.spec.ts >> Dashboard route audit smoke >> keeps personal notifications available while removed chat routes stay unavailable
- Location: e2e/dashboard-route-audit.spec.ts:125:7

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('heading', { name: /Chat has been removed/i })
Expected: visible
Timeout: 10000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 10000ms
  - waiting for getByRole('heading', { name: /Chat has been removed/i })

```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - generic [ref=e2]:
    - main [ref=e3]:
      - region "SchoolOS could not verify access" [ref=e4]:
        - generic [ref=e5]:
          - img [ref=e7]
          - generic [ref=e9]:
            - paragraph [ref=e10]: Secure session check unavailable
            - heading "SchoolOS could not verify access" [level=1] [ref=e11]
        - paragraph [ref=e12]: SchoolOS reached the service, but the session check returned an unexpected response. Private school information stays hidden until a fresh check succeeds.
        - status [ref=e13]:
          - text: Retry the secure session check. If it keeps failing, contact the SchoolOS administrator with the time of the attempt.
          - paragraph [ref=e14]: Unsynced attendance drafts remain on this browser and have not been sent or deleted.
        - button "Check session securely" [ref=e15] [cursor=pointer]:
          - img [ref=e16]
          - text: Check session securely
    - region "Notifications alt+T"
  - alert [ref=e21]
```

# Test source

```ts
  43  |   '/dashboard/academics/assessment-components',
  44  |   '/dashboard/academics/marks',
  45  |   '/dashboard/academics/cas',
  46  |   '/dashboard/academics/results',
  47  |   '/dashboard/academics/locks',
  48  |   '/dashboard/academics/report-cards',
  49  |   '/dashboard/academics/promotion',
  50  |   '/dashboard/academics/publishing',
  51  |   '/dashboard/homework',
  52  |   '/dashboard/timetable',
  53  |   '/dashboard/hr',
  54  |   '/dashboard/payroll',
  55  |   '/dashboard/accounting',
  56  |   '/dashboard/reports',
  57  |   '/dashboard/settings',
  58  | ] as const;
  59  | 
  60  | const platformRoutes = [
  61  |   '/platform/dashboard',
  62  |   '/platform/schools',
  63  |   '/platform/schools?workflow=subscriptions',
  64  |   '/platform/audit',
  65  |   '/platform/settings?tab=plans',
  66  |   '/platform/settings/plans',
  67  | ] as const;
  68  | 
  69  | const platformApiPathsByRoute: Record<(typeof platformRoutes)[number], RegExp> =
  70  |   {
  71  |     '/platform/dashboard': /\/platform\/dashboard(?:$|[?#])?/,
  72  |     '/platform/schools': /\/platform\/tenants(?:$|[/?#])?/,
  73  |     '/platform/schools?workflow=subscriptions':
  74  |       /\/platform\/tenants(?:$|[/?#])?/,
  75  |     '/platform/audit': /\/platform\/audit-logs(?:$|[/?#])?/,
  76  |     '/platform/settings?tab=plans': /\/platform\/plans(?:$|[?#])?/,
  77  |     '/platform/settings/plans': /\/platform\/plans(?:$|[?#])?/,
  78  |   };
  79  | 
  80  | const tenantApiPathsByRoute = {
  81  |   '/dashboard': /\/auth\/me(?:$|[?#])?|\/academic-years(?:$|[/?#])?/,
  82  |   '/dashboard/students': /\/students(?:$|[/?#])?/,
  83  |   '/dashboard/attendance': /\/attendance(?:$|[/?#])?/,
  84  |   '/dashboard/fees': /\/fees(?:$|[/?#])?/,
  85  |   '/dashboard/settings': /\/settings(?:$|[/?#])?|\/tenant-settings(?:$|[/?#])?/,
  86  | } as const;
  87  | 
  88  | test.describe('Dashboard route audit smoke', () => {
  89  |   test.beforeEach(() => {
  90  |     test.skip(
  91  |       !schoolCredentials.tenantSlug ||
  92  |         !schoolCredentials.email ||
  93  |         !schoolCredentials.password,
  94  |       'Set school E2E credentials to run authenticated route audit.',
  95  |     );
  96  |   });
  97  | 
  98  |   test('loads every active P0 school dashboard route without a fatal page', async ({
  99  |     page,
  100 |   }) => {
  101 |     const pageErrors: string[] = [];
  102 |     page.on('pageerror', (error) => pageErrors.push(error.message));
  103 | 
  104 |     await login(page, schoolCredentials);
  105 |     await expect(page.getByLabel(/User profile menu/i)).toBeVisible();
  106 | 
  107 |     for (const route of schoolRoutes) {
  108 |       await page.goto(route);
  109 |       await expectUsableRoute(page, route);
  110 |     }
  111 | 
  112 |     await page.goto('/dashboard/students');
  113 |     const firstStudentLink = page
  114 |       .locator('a[href^="/dashboard/students/"]')
  115 |       .first();
  116 | 
  117 |     if (await firstStudentLink.isVisible()) {
  118 |       await firstStudentLink.click();
  119 |       await expectUsableRoute(page, '/dashboard/students/[studentId]');
  120 |     }
  121 | 
  122 |     expect(pageErrors, pageErrors.join('\n')).toEqual([]);
  123 |   });
  124 | 
  125 |   test('keeps personal notifications available while removed chat routes stay unavailable', async ({
  126 |     page,
  127 |   }) => {
  128 |     await login(page, schoolCredentials);
  129 | 
  130 |     const notificationButton = page.getByRole('button', {
  131 |       name: /Notifications/i,
  132 |     });
  133 |     await expect(notificationButton).toBeVisible();
  134 |     await notificationButton.click();
  135 |     await expect(page.getByTestId('notification-panel')).toBeVisible();
  136 | 
  137 |     await expect(page.getByRole('link', { name: /^Messages$/i })).toHaveCount(
  138 |       0,
  139 |     );
  140 |     await page.goto('/dashboard/messages');
  141 |     await expect(
  142 |       page.getByRole('heading', { name: /Chat has been removed/i }),
> 143 |     ).toBeVisible();
      |       ^ Error: expect(locator).toBeVisible() failed
  144 |   });
  145 | });
  146 | 
  147 | test.describe('Platform route audit smoke', () => {
  148 |   test.beforeEach(() => {
  149 |     test.skip(
  150 |       !platformCredentials.tenantSlug ||
  151 |         !platformCredentials.email ||
  152 |         !platformCredentials.password,
  153 |       'Set platform E2E credentials to run platform route audit.',
  154 |     );
  155 |   });
  156 | 
  157 |   test('loads implemented platform routes for platform users', async ({
  158 |     page,
  159 |   }) => {
  160 |     await login(page, platformCredentials);
  161 | 
  162 |     for (const route of platformRoutes) {
  163 |       await page.goto(route);
  164 |       await expectUsableRoute(page, route);
  165 |     }
  166 |   });
  167 | });
  168 | 
  169 | test.describe('Browser-level platform and school route denial', () => {
  170 |   test.beforeEach(() => {
  171 |     test.skip(
  172 |       !schoolCredentials.tenantSlug ||
  173 |         !schoolCredentials.email ||
  174 |         !schoolCredentials.password ||
  175 |         !platformCredentials.tenantSlug ||
  176 |         !platformCredentials.email ||
  177 |         !platformCredentials.password,
  178 |       'Set both school and platform E2E credentials to run route-denial audit.',
  179 |     );
  180 |   });
  181 | 
  182 |   test('denies school users from platform control-plane routes', async ({
  183 |     page,
  184 |   }) => {
  185 |     await login(page, schoolCredentials);
  186 | 
  187 |     for (const route of platformRoutes) {
  188 |       await expectRouteDenied(page, route, platformApiPathsByRoute[route]);
  189 |       await expect(
  190 |         page.getByRole('heading', { name: /Platform Dashboard/i }),
  191 |       ).toHaveCount(0);
  192 |     }
  193 |   });
  194 | 
  195 |   test('denies platform users from tenant school operation routes', async ({
  196 |     page,
  197 |   }) => {
  198 |     await login(page, platformCredentials);
  199 | 
  200 |     for (const [route, apiPattern] of Object.entries(tenantApiPathsByRoute)) {
  201 |       await expectRouteDenied(page, route, apiPattern);
  202 |     }
  203 |   });
  204 | });
  205 | 
  206 | async function login(
  207 |   page: Page,
  208 |   credentials: {
  209 |     tenantSlug?: string;
  210 |     email?: string;
  211 |     password?: string;
  212 |   },
  213 | ) {
  214 |   await page.goto('/login');
  215 |   await page.getByLabel(/School Code/i).fill(credentials.tenantSlug ?? '');
  216 |   await page.getByLabel(/Email/i).fill(credentials.email ?? '');
  217 |   await page.getByLabel(/^Password$/i).fill(credentials.password ?? '');
  218 |   await page.getByRole('button', { name: /Sign in/i }).click();
  219 |   await page.waitForURL(/\/(?:dashboard|platform)(?:$|[/?#])/, {
  220 |     timeout: 20_000,
  221 |   });
  222 | }
  223 | 
  224 | async function expectUsableRoute(page: Page, route: string) {
  225 |   await expect(
  226 |     page
  227 |       .locator('h1:visible, h2:visible, h3:visible, [role="heading"]:visible')
  228 |       .first(),
  229 |   ).toBeVisible({ timeout: 15_000 });
  230 |   await expect(
  231 |     page.getByText(
  232 |       /Application error|Unhandled Runtime Error|This page could not be found|Internal Server Error/i,
  233 |     ),
  234 |     `${route} rendered a framework or fatal error page`,
  235 |   ).toHaveCount(0);
  236 | }
  237 | 
  238 | async function expectRouteDenied(
  239 |   page: Page,
  240 |   route: string,
  241 |   apiPattern: RegExp,
  242 | ) {
  243 |   const denialPattern =
```