# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: dashboard-route-audit.spec.ts >> Browser-level platform and school route denial >> denies platform users from tenant school operation routes
- Location: e2e/dashboard-route-audit.spec.ts:195:7

# Error details

```
TimeoutError: page.waitForURL: Timeout 20000ms exceeded.
=========================== logs ===========================
waiting for navigation until "load"
============================================================
```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - generic [ref=e2]:
    - main [ref=e3]:
      - generic [ref=e4]:
        - link "S SchoolOS" [ref=e6] [cursor=pointer]:
          - /url: /
          - generic [ref=e7]: S
          - generic [ref=e8]: SchoolOS
        - generic [ref=e9]:
          - generic [ref=e10]: Staff & Admin Portal
          - heading "Simple access to your school workspace." [level=1] [ref=e11]
          - paragraph [ref=e12]: Sign in to manage attendance, fees, students, reports, and daily school operations from one clear place.
          - list [ref=e13]:
            - listitem [ref=e14]:
              - img [ref=e16]
              - generic [ref=e20]:
                - paragraph [ref=e21]: Staff access
                - paragraph [ref=e22]: Use the school code and credentials provided by your administrator.
            - listitem [ref=e23]:
              - img [ref=e25]
              - generic [ref=e28]:
                - paragraph [ref=e29]: School workspace
                - paragraph [ref=e30]: Each school uses its own workspace for day-to-day operations with school-level data isolation.
            - listitem [ref=e31]:
              - img [ref=e33]
              - generic [ref=e37]:
                - paragraph [ref=e38]: Organized records
                - paragraph [ref=e39]: Attendance, fees, students, and reports stay easier to manage.
        - generic [ref=e40]: "Parents & Guardians: Please use the SchoolOS mobile app to log in."
      - generic [ref=e42]:
        - generic [ref=e43]:
          - heading "Welcome back" [level=2] [ref=e44]
          - paragraph [ref=e45]: Sign in to your school workspace.
        - generic [ref=e47]:
          - generic [ref=e48]:
            - generic [ref=e49]: School Code
            - textbox "School Code" [ref=e50]:
              - /placeholder: e.g. green-valley-school
              - text: platform
            - paragraph [ref=e51]: Enter the school code provided by your school administrator.
          - generic [ref=e52]:
            - generic [ref=e53]: Email
            - textbox "Email" [ref=e54]:
              - /placeholder: admin@school.edu.np
              - text: platform@schoolos.com
          - generic [ref=e55]:
            - generic [ref=e56]: Password
            - generic [ref=e57]:
              - textbox "Password" [ref=e58]:
                - /placeholder: Enter your password
                - text: ci-e2e-demo-password-not-for-production-use
              - button "Show password" [ref=e59] [cursor=pointer]:
                - img [ref=e60]
          - button "Sign in" [ref=e63] [cursor=pointer]
          - alert [ref=e64]: "ThrottlerException: Too Many Requests"
          - link "Forgot password?" [ref=e66] [cursor=pointer]:
            - /url: /forgot-password
        - generic [ref=e67]:
          - paragraph [ref=e68]: Need access? Contact your school administrator.
          - paragraph [ref=e69]:
            - text: New school?
            - link "Request a demo." [ref=e70] [cursor=pointer]:
              - /url: /request-demo
    - region "Notifications alt+T"
  - alert [ref=e71]
```

# Test source

```ts
  119 |       await expectUsableRoute(page, '/dashboard/students/[studentId]');
  120 |     }
  121 | 
  122 |     expect(pageErrors, pageErrors.join('\n')).toEqual([]);
  123 |   });
  124 | 
  125 |   test('keeps personal notifications available while removed chat routes stay unavailable', async ({
  126 |     page,
  127 |   }) => {
  128 |     await login(page, schoolCredentials);
  129 | 
  130 |     const notificationButton = page.getByRole('button', {
  131 |       name: /Notifications/i,
  132 |     });
  133 |     await expect(notificationButton).toBeVisible();
  134 |     await notificationButton.click();
  135 |     await expect(page.getByTestId('notification-panel')).toBeVisible();
  136 | 
  137 |     await expect(page.getByRole('link', { name: /^Messages$/i })).toHaveCount(
  138 |       0,
  139 |     );
  140 |     await page.goto('/dashboard/messages');
  141 |     await expect(
  142 |       page.getByRole('heading', { name: /Chat has been removed/i }),
  143 |     ).toBeVisible();
  144 |   });
  145 | });
  146 | 
  147 | test.describe('Platform route audit smoke', () => {
  148 |   test.beforeEach(() => {
  149 |     test.skip(
  150 |       !platformCredentials.tenantSlug ||
  151 |         !platformCredentials.email ||
  152 |         !platformCredentials.password,
  153 |       'Set platform E2E credentials to run platform route audit.',
  154 |     );
  155 |   });
  156 | 
  157 |   test('loads implemented platform routes for platform users', async ({
  158 |     page,
  159 |   }) => {
  160 |     await login(page, platformCredentials);
  161 | 
  162 |     for (const route of platformRoutes) {
  163 |       await page.goto(route);
  164 |       await expectUsableRoute(page, route);
  165 |     }
  166 |   });
  167 | });
  168 | 
  169 | test.describe('Browser-level platform and school route denial', () => {
  170 |   test.beforeEach(() => {
  171 |     test.skip(
  172 |       !schoolCredentials.tenantSlug ||
  173 |         !schoolCredentials.email ||
  174 |         !schoolCredentials.password ||
  175 |         !platformCredentials.tenantSlug ||
  176 |         !platformCredentials.email ||
  177 |         !platformCredentials.password,
  178 |       'Set both school and platform E2E credentials to run route-denial audit.',
  179 |     );
  180 |   });
  181 | 
  182 |   test('denies school users from platform control-plane routes', async ({
  183 |     page,
  184 |   }) => {
  185 |     await login(page, schoolCredentials);
  186 | 
  187 |     for (const route of platformRoutes) {
  188 |       await expectRouteDenied(page, route, platformApiPathsByRoute[route]);
  189 |       await expect(
  190 |         page.getByRole('heading', { name: /Platform Dashboard/i }),
  191 |       ).toHaveCount(0);
  192 |     }
  193 |   });
  194 | 
  195 |   test('denies platform users from tenant school operation routes', async ({
  196 |     page,
  197 |   }) => {
  198 |     await login(page, platformCredentials);
  199 | 
  200 |     for (const [route, apiPattern] of Object.entries(tenantApiPathsByRoute)) {
  201 |       await expectRouteDenied(page, route, apiPattern);
  202 |     }
  203 |   });
  204 | });
  205 | 
  206 | async function login(
  207 |   page: Page,
  208 |   credentials: {
  209 |     tenantSlug?: string;
  210 |     email?: string;
  211 |     password?: string;
  212 |   },
  213 | ) {
  214 |   await page.goto('/login');
  215 |   await page.getByLabel(/School Code/i).fill(credentials.tenantSlug ?? '');
  216 |   await page.getByLabel(/Email/i).fill(credentials.email ?? '');
  217 |   await page.getByLabel(/^Password$/i).fill(credentials.password ?? '');
  218 |   await page.getByRole('button', { name: /Sign in/i }).click();
> 219 |   await page.waitForURL(/\/(?:dashboard|platform)(?:$|[/?#])/, {
      |              ^ TimeoutError: page.waitForURL: Timeout 20000ms exceeded.
  220 |     timeout: 20_000,
  221 |   });
  222 | }
  223 | 
  224 | async function expectUsableRoute(page: Page, route: string) {
  225 |   await expect(
  226 |     page
  227 |       .locator('h1:visible, h2:visible, h3:visible, [role="heading"]:visible')
  228 |       .first(),
  229 |   ).toBeVisible({ timeout: 15_000 });
  230 |   await expect(
  231 |     page.getByText(
  232 |       /Application error|Unhandled Runtime Error|This page could not be found|Internal Server Error/i,
  233 |     ),
  234 |     `${route} rendered a framework or fatal error page`,
  235 |   ).toHaveCount(0);
  236 | }
  237 | 
  238 | async function expectRouteDenied(
  239 |   page: Page,
  240 |   route: string,
  241 |   apiPattern: RegExp,
  242 | ) {
  243 |   const denialPattern =
  244 |     /Access restricted|Insufficient platform permissions|Access denied|Forbidden|not authorized|Authentication required|Request failed with status 401|Request failed with status 403/i;
  245 |   const denialMessage = page.getByText(denialPattern).first();
  246 |   const deniedResponsePromise = page
  247 |     .waitForResponse(
  248 |       (response) =>
  249 |         apiPattern.test(response.url()) &&
  250 |         [401, 403].includes(response.status()),
  251 |       { timeout: 5_000 },
  252 |     )
  253 |     .catch(() => null);
  254 | 
  255 |   await page.goto(route, { waitUntil: 'domcontentloaded' });
  256 |   await page.waitForTimeout(300);
  257 | 
  258 |   const currentPath = new URL(page.url()).pathname;
  259 |   if (route.startsWith('/platform') && !currentPath.startsWith('/platform')) {
  260 |     expect(currentPath).toMatch(/^\/(?:dashboard|login)$/);
  261 |     return;
  262 |   }
  263 | 
  264 |   if (await denialMessage.isVisible().catch(() => false)) {
  265 |     return;
  266 |   }
  267 | 
  268 |   const deniedResponse = await deniedResponsePromise;
  269 | 
  270 |   if (deniedResponse) {
  271 |     expect([401, 403]).toContain(deniedResponse.status());
  272 |     return;
  273 |   }
  274 | 
  275 |   await expect(
  276 |     denialMessage,
  277 |     `${route} should render an authorization denial when no denied API response is observable`,
  278 |   ).toBeVisible({ timeout: 5_000 });
  279 | }
  280 | 
```