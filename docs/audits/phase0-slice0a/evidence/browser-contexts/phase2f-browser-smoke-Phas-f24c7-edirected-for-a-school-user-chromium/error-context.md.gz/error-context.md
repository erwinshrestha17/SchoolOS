# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: phase2f-browser-smoke.spec.ts >> Phase 2F.2 authenticated school admin browser smoke >> platform routes are denied or redirected for a school user
- Location: e2e/phase2f-browser-smoke.spec.ts:213:7

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('main').getByText(/permission|not authorized|access denied|School Dashboard/i).first()
Expected: visible
Timeout: 10000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 10000ms
  - waiting for locator('main').getByText(/permission|not authorized|access denied|School Dashboard/i).first()

```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - generic [ref=e2]:
    - main [ref=e3]:
      - region "SchoolOS could not verify access" [ref=e4]:
        - generic [ref=e5]:
          - img [ref=e7]
          - generic [ref=e9]:
            - paragraph [ref=e10]: Secure session check unavailable
            - heading "SchoolOS could not verify access" [level=1] [ref=e11]
        - paragraph [ref=e12]: SchoolOS reached the service, but the session check returned an unexpected response. Private school information stays hidden until a fresh check succeeds.
        - status [ref=e13]:
          - text: Retry the secure session check. If it keeps failing, contact the SchoolOS administrator with the time of the attempt.
          - paragraph [ref=e14]: Unsynced attendance drafts remain on this browser and have not been sent or deleted.
        - button "Check session securely" [ref=e15] [cursor=pointer]:
          - img [ref=e16]
          - text: Check session securely
    - region "Notifications alt+T"
  - alert [ref=e21]
```

# Test source

```ts
  128 |       .getByLabel(
  129 |         /Search students by name, student code, guardian name, or phone/i,
  130 |       )
  131 |       .fill('STU001');
  132 |     await expect(page.locator('main')).toContainText(
  133 |       /Student Roster|No students found|STU001|S2024-001/i,
  134 |       { timeout: 10_000 },
  135 |     );
  136 | 
  137 |     // Test search with no results
  138 |     await page
  139 |       .getByLabel(
  140 |         /Search students by name, student code, guardian name, or phone/i,
  141 |       )
  142 |       .fill('NoSuchStudentForSmoke');
  143 |     await expect(
  144 |       page.getByText('No students match these filters', { exact: true }),
  145 |     ).toBeVisible();
  146 | 
  147 |     await page.getByRole('button', { name: 'Reset', exact: true }).click();
  148 | 
  149 |     const firstStudent = page
  150 |       .locator('a[href^="/dashboard/students/"]')
  151 |       .first();
  152 |     if (await firstStudent.isVisible()) {
  153 |       await firstStudent.click();
  154 |       await expect(page.locator('main h1').first()).toBeVisible();
  155 |       await expect(page.getByRole('button', { name: /Edit/i })).toBeVisible();
  156 |       await expect(
  157 |         page.getByRole('button', { name: /ID Card/i }),
  158 |       ).toBeVisible();
  159 |       await expect(page.getByRole('tab', { name: /Documents/i })).toBeVisible();
  160 |       await expect(page.getByRole('tab', { name: /History/i })).toBeVisible();
  161 |       await expect(page.getByText(/QR Identity|QR/i).first()).toBeVisible();
  162 |       await page.getByRole('tab', { name: /Documents/i }).click();
  163 |       await expect(page.getByText(/Document Audit Trail/i)).toBeVisible();
  164 |       await page.getByRole('button', { name: /Edit/i }).click();
  165 |       await expect(page.getByText(/Student Photo/i)).toBeVisible();
  166 |       await expect(
  167 |         page
  168 |           .getByText(/Upload|Replace/i)
  169 |           .or(page.getByText(/Remove/i))
  170 |           .first(),
  171 |       ).toBeVisible();
  172 |     }
  173 |   });
  174 | 
  175 |   test('attendance and admissions validation controls render', async ({
  176 |     page,
  177 |   }) => {
  178 |     await page.goto('/dashboard/attendance/mark');
  179 |     await expect(page.getByLabel(/^Class$/i)).toBeVisible();
  180 |     await expect(page.getByLabel(/^Date$/i)).toBeVisible();
  181 |     await expect(page.locator('main')).toContainText(
  182 |       /Smart Attendance|Attendance Roster|Expected Students/i,
  183 |     );
  184 | 
  185 |     await page.goto('/dashboard/admissions');
  186 |     await expect(
  187 |       page
  188 |         .locator('main')
  189 |         .getByRole('heading', { name: 'Admissions', exact: true }),
  190 |     ).toBeVisible();
  191 |     await page
  192 |       .locator('[data-schoolos-ui="module-header"]')
  193 |       .getByRole('link', { name: 'New admission', exact: true })
  194 |       .click();
  195 |     await expect(
  196 |       page.locator('main').getByRole('heading', { name: /New admission/i }),
  197 |     ).toBeVisible();
  198 |     await page
  199 |       .getByRole('button', {
  200 |         name: 'Start school-office admission',
  201 |         exact: true,
  202 |       })
  203 |       .click();
  204 |     await expect(
  205 |       page.getByRole('heading', { name: 'Student and guardian', exact: true }),
  206 |     ).toBeVisible();
  207 |     await page.getByRole('button', { name: 'Continue', exact: true }).click();
  208 |     await expect(
  209 |       page.getByText('Enter valid student names.', { exact: true }),
  210 |     ).toBeVisible();
  211 |   });
  212 | 
  213 |   test('platform routes are denied or redirected for a school user', async ({
  214 |     page,
  215 |   }) => {
  216 |     await page.goto('/platform/dashboard');
  217 |     await expectNoFatalPage(page, '/platform/dashboard');
  218 | 
  219 |     const platformUrl = page.url().includes('/platform');
  220 |     if (platformUrl) {
  221 |       await expect(
  222 |         page
  223 |           .locator('main')
  224 |           .getByText(
  225 |             /permission|not authorized|access denied|School Dashboard/i,
  226 |           )
  227 |           .first(),
> 228 |       ).toBeVisible();
      |         ^ Error: expect(locator).toBeVisible() failed
  229 |     } else {
  230 |       await expect(page).toHaveURL(/\/(?:dashboard|login)(?:$|[/?#])/);
  231 |     }
  232 |   });
  233 | });
  234 | 
  235 | test.describe('Phase 2F.2 platform browser smoke', () => {
  236 |   test.beforeEach(async ({ context, page }) => {
  237 |     test.skip(
  238 |       !platformCredentials.tenantSlug ||
  239 |         !platformCredentials.email ||
  240 |         !platformCredentials.password,
  241 |       'Platform browser smoke requires platform seed credentials.',
  242 |     );
  243 |     await context.clearCookies();
  244 |     await login(page, platformCredentials);
  245 |   });
  246 | 
  247 |   test('loads platform pilot onboarding surfaces for platform users', async ({
  248 |     page,
  249 |   }) => {
  250 |     for (const route of [
  251 |       '/platform/dashboard',
  252 |       '/platform/schools',
  253 |       '/platform/settings',
  254 |     ]) {
  255 |       await page.goto(route);
  256 |       await expect(
  257 |         page
  258 |           .locator('h1:visible, h2:visible, [role="heading"]:visible')
  259 |           .first(),
  260 |       ).toBeVisible({ timeout: 15_000 });
  261 |       await expectNoFatalPage(page, route);
  262 |     }
  263 |   });
  264 | });
  265 | 
  266 | async function login(
  267 |   page: Page,
  268 |   credentials: {
  269 |     tenantSlug?: string;
  270 |     email?: string;
  271 |     password?: string;
  272 |   },
  273 | ) {
  274 |   await page.goto('/login');
  275 |   await page.getByLabel(/School Code/i).fill(credentials.tenantSlug ?? '');
  276 |   await page.getByLabel(/Email/i).fill(credentials.email ?? '');
  277 |   await page.getByLabel(/^Password$/i).fill(credentials.password ?? '');
  278 |   await page.getByRole('button', { name: /Sign in/i }).click();
  279 | 
  280 |   // Wait for either the dashboard/platform or an error message
  281 |   await Promise.race([
  282 |     page.waitForURL(/\/(?:dashboard|platform)(?:$|[/?#])/, { timeout: 20_000 }),
  283 |     expect(
  284 |       page
  285 |         .getByText(/Invalid credentials|Account suspended|not authorized/i)
  286 |         .first(),
  287 |     ).toBeVisible({ timeout: 20_000 }),
  288 |   ]);
  289 | 
  290 |   if (!page.url().includes('/dashboard') && !page.url().includes('/platform')) {
  291 |     throw new Error(
  292 |       `Login failed for ${credentials.email}. Still at ${page.url()}`,
  293 |     );
  294 |   }
  295 | 
  296 |   if (page.url().includes('/platform')) {
  297 |     await expect(
  298 |       page
  299 |         .getByRole('button', { name: /Logout/i })
  300 |         .or(page.getByText(/Platform operator console/i))
  301 |         .first(),
  302 |     ).toBeVisible({ timeout: 15_000 });
  303 |     return;
  304 |   }
  305 | 
  306 |   await expect(
  307 |     page.getByRole('button', { name: /User profile menu/i }),
  308 |   ).toBeVisible({ timeout: 15_000 });
  309 | }
  310 | 
  311 | async function expectNoFatalPage(page: Page, route: string) {
  312 |   const fatalMessages = [
  313 |     /Application error/i,
  314 |     /Unhandled Runtime Error/i,
  315 |     /This page could not be found/i,
  316 |     /Internal Server Error/i,
  317 |     /Next.js-specific error/i,
  318 |     /500 - Internal Server Error/i,
  319 |     /404 - Page Not Found/i,
  320 |   ];
  321 | 
  322 |   for (const msg of fatalMessages) {
  323 |     await expect(
  324 |       page.getByText(msg),
  325 |       `${route} rendered a fatal page matching ${msg}`,
  326 |     ).toHaveCount(0);
  327 |   }
  328 | }
```