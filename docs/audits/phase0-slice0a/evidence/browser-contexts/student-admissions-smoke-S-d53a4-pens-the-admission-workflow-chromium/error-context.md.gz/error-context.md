# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: student-admissions-smoke.spec.ts >> Students & Admissions Workflow Smoke >> keeps Students selected, preserves lifecycle state, and opens the admission workflow
- Location: e2e/student-admissions-smoke.spec.ts:91:7

# Error details

```
TimeoutError: page.waitForURL: Timeout 20000ms exceeded.
=========================== logs ===========================
waiting for navigation to "**/dashboard*" until "load"
============================================================
```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - generic [ref=e2]:
    - main [ref=e3]:
      - generic [ref=e4]:
        - link "S SchoolOS" [ref=e6] [cursor=pointer]:
          - /url: /
          - generic [ref=e7]: S
          - generic [ref=e8]: SchoolOS
        - generic [ref=e9]:
          - generic [ref=e10]: Staff & Admin Portal
          - heading "Simple access to your school workspace." [level=1] [ref=e11]
          - paragraph [ref=e12]: Sign in to manage attendance, fees, students, reports, and daily school operations from one clear place.
          - list [ref=e13]:
            - listitem [ref=e14]:
              - img [ref=e16]
              - generic [ref=e20]:
                - paragraph [ref=e21]: Staff access
                - paragraph [ref=e22]: Use the school code and credentials provided by your administrator.
            - listitem [ref=e23]:
              - img [ref=e25]
              - generic [ref=e28]:
                - paragraph [ref=e29]: School workspace
                - paragraph [ref=e30]: Each school uses its own workspace for day-to-day operations with school-level data isolation.
            - listitem [ref=e31]:
              - img [ref=e33]
              - generic [ref=e37]:
                - paragraph [ref=e38]: Organized records
                - paragraph [ref=e39]: Attendance, fees, students, and reports stay easier to manage.
        - generic [ref=e40]: "Parents & Guardians: Please use the SchoolOS mobile app to log in."
      - generic [ref=e42]:
        - generic [ref=e43]:
          - heading "Welcome back" [level=2] [ref=e44]
          - paragraph [ref=e45]: Sign in to your school workspace.
        - generic [ref=e47]:
          - generic [ref=e48]:
            - generic [ref=e49]: School Code
            - textbox "School Code" [ref=e50]:
              - /placeholder: e.g. green-valley-school
              - text: default-school
            - paragraph [ref=e51]: Enter the school code provided by your school administrator.
          - generic [ref=e52]:
            - generic [ref=e53]: Email
            - textbox "Email" [ref=e54]:
              - /placeholder: admin@school.edu.np
              - text: admin@schoolos.com
          - generic [ref=e55]:
            - generic [ref=e56]: Password
            - generic [ref=e57]:
              - textbox "Password" [ref=e58]:
                - /placeholder: Enter your password
                - text: ci-e2e-demo-password-not-for-production-use
              - button "Show password" [ref=e59] [cursor=pointer]:
                - img [ref=e60]
          - button "Sign in" [ref=e63] [cursor=pointer]
          - alert [ref=e64]: "ThrottlerException: Too Many Requests"
          - link "Forgot password?" [ref=e66] [cursor=pointer]:
            - /url: /forgot-password
        - generic [ref=e67]:
          - paragraph [ref=e68]: Need access? Contact your school administrator.
          - paragraph [ref=e69]:
            - text: New school?
            - link "Request a demo." [ref=e70] [cursor=pointer]:
              - /url: /request-demo
    - region "Notifications alt+T"
  - alert [ref=e71]
```

# Test source

```ts
  488 |       assessmentSession: {
  489 |         status: string;
  490 |         result: string | null;
  491 |         resultScore: number | null;
  492 |       } | null;
  493 |     }>(await caseResponse.json());
  494 |     expect(evaluation.assessmentSession?.status).toBe("COMPLETED");
  495 |     expect(evaluation.assessmentSession?.result).toBe("PASSED");
  496 |     expect(evaluation.assessmentSession?.resultScore).toBe(82);
  497 |   });
  498 | });
  499 | 
  500 | function unwrapApiData<T>(payload: unknown): T {
  501 |   if (typeof payload === "object" && payload !== null && "data" in payload) {
  502 |     return (payload as { data: T }).data;
  503 |   }
  504 |   return payload as T;
  505 | }
  506 | 
  507 | function alphabeticSuffix(value: number) {
  508 |   let remaining = value;
  509 |   let result = "";
  510 |   while (remaining > 0) {
  511 |     result = String.fromCharCode(97 + (remaining % 26)) + result;
  512 |     remaining = Math.floor(remaining / 26);
  513 |   }
  514 |   return result || "a";
  515 | }
  516 | 
  517 | function pad2(value: number) {
  518 |   return String(value).padStart(2, "0");
  519 | }
  520 | 
  521 | async function ensureActiveQrCredential(page: Page) {
  522 |   const generateButton = page.getByRole("button", {
  523 |     name: "Generate Identity",
  524 |   });
  525 |   if (await generateButton.isVisible()) {
  526 |     await generateButton.click();
  527 |     await expect(page.getByText("Protected ID card generated")).toBeVisible();
  528 |     await page.getByRole("button", { name: "Done" }).click();
  529 |   }
  530 | 
  531 |   await expect(
  532 |     page.getByRole("button", { name: "Rotate (Lost Card)" }),
  533 |   ).toBeVisible();
  534 | }
  535 | 
  536 | async function expectDesktopSummaryRow(page: Page) {
  537 |   const cards = page
  538 |     .locator('[data-schoolos-ui="summary-grid"]')
  539 |     .first()
  540 |     .locator(":scope > a");
  541 |   await expect(cards).toHaveCount(4);
  542 |   const first = await cards.nth(0).boundingBox();
  543 |   const last = await cards.nth(3).boundingBox();
  544 |   expect(Math.abs((first?.y ?? 0) - (last?.y ?? 0))).toBeLessThanOrEqual(2);
  545 | }
  546 | 
  547 | async function expectNoHorizontalTabOverflow(page: Page, name: string) {
  548 |   const tabs = page.getByRole("tablist", { name });
  549 |   const dimensions = await tabs.evaluate((element) => ({
  550 |     clientWidth: element.clientWidth,
  551 |     scrollWidth: element.scrollWidth,
  552 |   }));
  553 |   expect(dimensions.scrollWidth).toBeLessThanOrEqual(
  554 |     dimensions.clientWidth + 1,
  555 |   );
  556 | }
  557 | 
  558 | async function expectResponsiveWorkspace(
  559 |   page: Page,
  560 |   workspaceTestId: string,
  561 |   tabListName: string,
  562 | ) {
  563 |   for (const width of [1280, 1024]) {
  564 |     await page.setViewportSize({ width, height: 900 });
  565 |     await expect(page.getByTestId(workspaceTestId)).toBeVisible();
  566 |     await expectNoHorizontalTabOverflow(page, tabListName);
  567 |   }
  568 | 
  569 |   await page.setViewportSize({ width: 390, height: 844 });
  570 |   await expect(page.getByTestId(workspaceTestId)).toBeVisible();
  571 |   await expect(page.getByRole("tablist", { name: tabListName })).toBeVisible();
  572 | 
  573 |   await page.setViewportSize({ width: 1440, height: 900 });
  574 | }
  575 | 
  576 | function sidebarLink(page: Page, name: string) {
  577 |   return page
  578 |     .getByRole("complementary")
  579 |     .getByRole("link", { name, exact: true });
  580 | }
  581 | 
  582 | async function login(page: Page) {
  583 |   await page.goto("/login");
  584 |   await page.getByLabel(/School Code/i).fill(credentials.tenantSlug ?? "");
  585 |   await page.getByLabel(/Email/i).fill(credentials.email ?? "");
  586 |   await page.getByLabel(/^Password$/i).fill(credentials.password ?? "");
  587 |   await page.getByRole("button", { name: /Sign in/i }).click();
> 588 |   await page.waitForURL("**/dashboard*", { timeout: 20_000 });
      |              ^ TimeoutError: page.waitForURL: Timeout 20000ms exceeded.
  589 | }
  590 | 
```