# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: phase2f-browser-smoke.spec.ts >> Phase 2F.2 platform browser smoke >> loads platform pilot onboarding surfaces for platform users
- Location: e2e/phase2f-browser-smoke.spec.ts:247:7

# Error details

```
TimeoutError: page.waitForURL: Timeout 20000ms exceeded.
=========================== logs ===========================
waiting for navigation until "load"
============================================================
```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - generic [ref=e2]:
    - main [ref=e3]:
      - generic [ref=e4]:
        - link "S SchoolOS" [ref=e6] [cursor=pointer]:
          - /url: /
          - generic [ref=e7]: S
          - generic [ref=e8]: SchoolOS
        - generic [ref=e9]:
          - generic [ref=e10]: Staff & Admin Portal
          - heading "Simple access to your school workspace." [level=1] [ref=e11]
          - paragraph [ref=e12]: Sign in to manage attendance, fees, students, reports, and daily school operations from one clear place.
          - list [ref=e13]:
            - listitem [ref=e14]:
              - img [ref=e16]
              - generic [ref=e20]:
                - paragraph [ref=e21]: Staff access
                - paragraph [ref=e22]: Use the school code and credentials provided by your administrator.
            - listitem [ref=e23]:
              - img [ref=e25]
              - generic [ref=e28]:
                - paragraph [ref=e29]: School workspace
                - paragraph [ref=e30]: Each school uses its own workspace for day-to-day operations with school-level data isolation.
            - listitem [ref=e31]:
              - img [ref=e33]
              - generic [ref=e37]:
                - paragraph [ref=e38]: Organized records
                - paragraph [ref=e39]: Attendance, fees, students, and reports stay easier to manage.
        - generic [ref=e40]: "Parents & Guardians: Please use the SchoolOS mobile app to log in."
      - generic [ref=e42]:
        - generic [ref=e43]:
          - heading "Welcome back" [level=2] [ref=e44]
          - paragraph [ref=e45]: Sign in to your school workspace.
        - generic [ref=e47]:
          - generic [ref=e48]:
            - generic [ref=e49]: School Code
            - textbox "School Code" [ref=e50]:
              - /placeholder: e.g. green-valley-school
              - text: platform
            - paragraph [ref=e51]: Enter the school code provided by your school administrator.
          - generic [ref=e52]:
            - generic [ref=e53]: Email
            - textbox "Email" [ref=e54]:
              - /placeholder: admin@school.edu.np
              - text: platform@schoolos.com
          - generic [ref=e55]:
            - generic [ref=e56]: Password
            - generic [ref=e57]:
              - textbox "Password" [ref=e58]:
                - /placeholder: Enter your password
                - text: ci-e2e-demo-password-not-for-production-use
              - button "Show password" [ref=e59] [cursor=pointer]:
                - img [ref=e60]
          - button "Sign in" [ref=e63] [cursor=pointer]
          - alert [ref=e64]: Invalid tenant or credentials
          - link "Forgot password?" [ref=e66] [cursor=pointer]:
            - /url: /forgot-password
        - generic [ref=e67]:
          - paragraph [ref=e68]: Need access? Contact your school administrator.
          - paragraph [ref=e69]:
            - text: New school?
            - link "Request a demo." [ref=e70] [cursor=pointer]:
              - /url: /request-demo
    - region "Notifications alt+T"
  - alert [ref=e71]
```

# Test source

```ts
  182 |       /Smart Attendance|Attendance Roster|Expected Students/i,
  183 |     );
  184 | 
  185 |     await page.goto('/dashboard/admissions');
  186 |     await expect(
  187 |       page
  188 |         .locator('main')
  189 |         .getByRole('heading', { name: 'Admissions', exact: true }),
  190 |     ).toBeVisible();
  191 |     await page
  192 |       .locator('[data-schoolos-ui="module-header"]')
  193 |       .getByRole('link', { name: 'New admission', exact: true })
  194 |       .click();
  195 |     await expect(
  196 |       page.locator('main').getByRole('heading', { name: /New admission/i }),
  197 |     ).toBeVisible();
  198 |     await page
  199 |       .getByRole('button', {
  200 |         name: 'Start school-office admission',
  201 |         exact: true,
  202 |       })
  203 |       .click();
  204 |     await expect(
  205 |       page.getByRole('heading', { name: 'Student and guardian', exact: true }),
  206 |     ).toBeVisible();
  207 |     await page.getByRole('button', { name: 'Continue', exact: true }).click();
  208 |     await expect(
  209 |       page.getByText('Enter valid student names.', { exact: true }),
  210 |     ).toBeVisible();
  211 |   });
  212 | 
  213 |   test('platform routes are denied or redirected for a school user', async ({
  214 |     page,
  215 |   }) => {
  216 |     await page.goto('/platform/dashboard');
  217 |     await expectNoFatalPage(page, '/platform/dashboard');
  218 | 
  219 |     const platformUrl = page.url().includes('/platform');
  220 |     if (platformUrl) {
  221 |       await expect(
  222 |         page
  223 |           .locator('main')
  224 |           .getByText(
  225 |             /permission|not authorized|access denied|School Dashboard/i,
  226 |           )
  227 |           .first(),
  228 |       ).toBeVisible();
  229 |     } else {
  230 |       await expect(page).toHaveURL(/\/(?:dashboard|login)(?:$|[/?#])/);
  231 |     }
  232 |   });
  233 | });
  234 | 
  235 | test.describe('Phase 2F.2 platform browser smoke', () => {
  236 |   test.beforeEach(async ({ context, page }) => {
  237 |     test.skip(
  238 |       !platformCredentials.tenantSlug ||
  239 |         !platformCredentials.email ||
  240 |         !platformCredentials.password,
  241 |       'Platform browser smoke requires platform seed credentials.',
  242 |     );
  243 |     await context.clearCookies();
  244 |     await login(page, platformCredentials);
  245 |   });
  246 | 
  247 |   test('loads platform pilot onboarding surfaces for platform users', async ({
  248 |     page,
  249 |   }) => {
  250 |     for (const route of [
  251 |       '/platform/dashboard',
  252 |       '/platform/schools',
  253 |       '/platform/settings',
  254 |     ]) {
  255 |       await page.goto(route);
  256 |       await expect(
  257 |         page
  258 |           .locator('h1:visible, h2:visible, [role="heading"]:visible')
  259 |           .first(),
  260 |       ).toBeVisible({ timeout: 15_000 });
  261 |       await expectNoFatalPage(page, route);
  262 |     }
  263 |   });
  264 | });
  265 | 
  266 | async function login(
  267 |   page: Page,
  268 |   credentials: {
  269 |     tenantSlug?: string;
  270 |     email?: string;
  271 |     password?: string;
  272 |   },
  273 | ) {
  274 |   await page.goto('/login');
  275 |   await page.getByLabel(/School Code/i).fill(credentials.tenantSlug ?? '');
  276 |   await page.getByLabel(/Email/i).fill(credentials.email ?? '');
  277 |   await page.getByLabel(/^Password$/i).fill(credentials.password ?? '');
  278 |   await page.getByRole('button', { name: /Sign in/i }).click();
  279 | 
  280 |   // Wait for either the dashboard/platform or an error message
  281 |   await Promise.race([
> 282 |     page.waitForURL(/\/(?:dashboard|platform)(?:$|[/?#])/, { timeout: 20_000 }),
      |          ^ TimeoutError: page.waitForURL: Timeout 20000ms exceeded.
  283 |     expect(
  284 |       page
  285 |         .getByText(/Invalid credentials|Account suspended|not authorized/i)
  286 |         .first(),
  287 |     ).toBeVisible({ timeout: 20_000 }),
  288 |   ]);
  289 | 
  290 |   if (!page.url().includes('/dashboard') && !page.url().includes('/platform')) {
  291 |     throw new Error(
  292 |       `Login failed for ${credentials.email}. Still at ${page.url()}`,
  293 |     );
  294 |   }
  295 | 
  296 |   if (page.url().includes('/platform')) {
  297 |     await expect(
  298 |       page
  299 |         .getByRole('button', { name: /Logout/i })
  300 |         .or(page.getByText(/Platform operator console/i))
  301 |         .first(),
  302 |     ).toBeVisible({ timeout: 15_000 });
  303 |     return;
  304 |   }
  305 | 
  306 |   await expect(
  307 |     page.getByRole('button', { name: /User profile menu/i }),
  308 |   ).toBeVisible({ timeout: 15_000 });
  309 | }
  310 | 
  311 | async function expectNoFatalPage(page: Page, route: string) {
  312 |   const fatalMessages = [
  313 |     /Application error/i,
  314 |     /Unhandled Runtime Error/i,
  315 |     /This page could not be found/i,
  316 |     /Internal Server Error/i,
  317 |     /Next.js-specific error/i,
  318 |     /500 - Internal Server Error/i,
  319 |     /404 - Page Not Found/i,
  320 |   ];
  321 | 
  322 |   for (const msg of fatalMessages) {
  323 |     await expect(
  324 |       page.getByText(msg),
  325 |       `${route} rendered a fatal page matching ${msg}`,
  326 |     ).toHaveCount(0);
  327 |   }
  328 | }
  329 | 
```