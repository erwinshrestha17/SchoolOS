# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: account-security.spec.ts >> M0 Account & Security browser E2E >> shows admin reset action in tenant-scoped user management
- Location: e2e/account-security.spec.ts:116:7

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('heading', { name: /Users & access/i })
Expected: visible
Timeout: 10000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 10000ms
  - waiting for getByRole('heading', { name: /Users & access/i })

```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - generic [ref=e2]:
    - main [ref=e3]:
      - region "SchoolOS could not verify access" [ref=e4]:
        - generic [ref=e5]:
          - img [ref=e7]
          - generic [ref=e9]:
            - paragraph [ref=e10]: Secure session check unavailable
            - heading "SchoolOS could not verify access" [level=1] [ref=e11]
        - paragraph [ref=e12]: SchoolOS reached the service, but the session check returned an unexpected response. Private school information stays hidden until a fresh check succeeds.
        - status [ref=e13]:
          - text: Retry the secure session check. If it keeps failing, contact the SchoolOS administrator with the time of the attempt.
          - paragraph [ref=e14]: Unsynced attendance drafts remain on this browser and have not been sent or deleted.
        - button "Check session securely" [ref=e15] [cursor=pointer]:
          - img [ref=e16]
          - text: Check session securely
    - region "Notifications alt+T"
  - alert [ref=e21]
```

# Test source

```ts
  28  |   temporaryPassword:
  29  |     process.env.SCHOOLOS_E2E_PASSWORD_TEST_TEMP ??
  30  |     process.env.SCHOOLOS_E2E_M0_SECURITY_PASSWORD ??
  31  |     'NepalPilot7!',
  32  |   finalPassword:
  33  |     process.env.SCHOOLOS_E2E_PASSWORD_TEST_FINAL ?? 'HimalayaDesk8!',
  34  | };
  35  | 
  36  | type Credentials = {
  37  |   tenantSlug?: string;
  38  |   email?: string;
  39  |   password?: string;
  40  | };
  41  | 
  42  | test.describe.serial('M0 Account & Security browser E2E', () => {
  43  |   test.beforeEach(async ({ context, page }) => {
  44  |     test.skip(
  45  |       !schoolCredentials.tenantSlug ||
  46  |         !schoolCredentials.email ||
  47  |         !schoolCredentials.password,
  48  |       'Account & Security E2E requires seeded school admin credentials.',
  49  |     );
  50  |     await requireHealthyApi(page);
  51  |     await clearBrowserSession(context, page);
  52  |   });
  53  | 
  54  |   test('shows school-friendly wrong-current-password feedback', async ({
  55  |     page,
  56  |   }) => {
  57  |     await login(page, schoolCredentials);
  58  |     await page.goto('/dashboard/settings/personal/security');
  59  |     await expect(
  60  |       page.getByRole('heading', { name: /Account & Security/i }),
  61  |     ).toBeVisible();
  62  | 
  63  |     await page.getByLabel(/^Current password$/i).fill('WrongCurrent1!');
  64  |     await page.getByLabel(/^New password$/i).fill('ValidWrong1!');
  65  |     await page.getByLabel(/^Confirm new password$/i).fill('ValidWrong1!');
  66  |     await page.getByRole('button', { name: /^Change password$/i }).click();
  67  | 
  68  |     await expect(
  69  |       page.getByText(
  70  |         /Current password is incorrect|Could not change password/i,
  71  |       ),
  72  |     ).toBeVisible();
  73  |   });
  74  | 
  75  |   test('shows neutral password rules and accessible live validation', async ({
  76  |     page,
  77  |   }) => {
  78  |     await login(page, schoolCredentials);
  79  |     await page.goto('/dashboard/settings/personal/security');
  80  | 
  81  |     const lengthRule = page
  82  |       .getByRole('listitem')
  83  |       .filter({ hasText: 'Minimum 8 characters' });
  84  |     const uppercaseRule = page
  85  |       .getByRole('listitem')
  86  |       .filter({ hasText: 'At least 1 uppercase letter' });
  87  |     const newPassword = page.getByLabel(/^New password$/i);
  88  |     const confirmation = page.getByLabel(/^Confirm new password$/i);
  89  |     const visibilityControl = page.getByRole('button', {
  90  |       // The accessible name flips between "Show new password" and
  91  |       // "Hide new password" when toggled, so this must match both states
  92  |       // for the same locator to keep resolving after the click below.
  93  |       name: /^(Show|Hide) new password$/i,
  94  |     });
  95  | 
  96  |     await expect(lengthRule).toContainText('Required');
  97  |     await expect(lengthRule).not.toContainText('Met');
  98  | 
  99  |     await newPassword.fill('longpassword1!');
  100 |     await expect(lengthRule).toContainText('Met');
  101 |     await expect(uppercaseRule).toContainText('Not met');
  102 | 
  103 |     await confirmation.fill('DoesNotMatch1!');
  104 |     await confirmation.blur();
  105 |     await expect(
  106 |       page.getByText(/Confirm password must match new password/i),
  107 |     ).toBeVisible();
  108 |     await expect(confirmation).toHaveAttribute('aria-invalid', 'true');
  109 | 
  110 |     await expect(newPassword).toHaveAttribute('type', 'password');
  111 |     await visibilityControl.click();
  112 |     await expect(newPassword).toHaveAttribute('type', 'text');
  113 |     await expect(visibilityControl).toHaveAttribute('aria-pressed', 'true');
  114 |   });
  115 | 
  116 |   test('shows admin reset action in tenant-scoped user management', async ({
  117 |     page,
  118 |   }) => {
  119 |     const loginResult = await login(page, schoolCredentials);
  120 |     test.skip(
  121 |       loginResult.mustChangePassword,
  122 |       'Admin reset visibility requires an admin account that is not forced through password change.',
  123 |     );
  124 | 
  125 |     await page.goto('/dashboard/settings/access/users');
  126 |     await expect(
  127 |       page.getByRole('heading', { name: /Users & access/i }),
> 128 |     ).toBeVisible();
      |       ^ Error: expect(locator).toBeVisible() failed
  129 |     await expect(
  130 |       page.getByRole('button', { name: /Reset password/i }).first(),
  131 |     ).toBeVisible();
  132 |   });
  133 | 
  134 |   test('admin reset forces next-login password change, then user changes password', async ({
  135 |     context,
  136 |     page,
  137 |   }) => {
  138 |     test.skip(
  139 |       !passwordTestAccount.email ||
  140 |         !passwordTestAccount.temporaryPassword ||
  141 |         !passwordTestAccount.finalPassword,
  142 |       'Set SCHOOLOS_E2E_PASSWORD_TEST_EMAIL, SCHOOLOS_E2E_PASSWORD_TEST_TEMP, and SCHOOLOS_E2E_PASSWORD_TEST_FINAL for mutating password E2E.',
  143 |     );
  144 | 
  145 |     const loginResult = await login(page, schoolCredentials);
  146 |     test.skip(
  147 |       loginResult.mustChangePassword,
  148 |       'Admin reset setup requires an admin account that is not forced through password change.',
  149 |     );
  150 | 
  151 |     await page.goto('/dashboard/settings/access/users');
  152 |     const userRow = page.getByTestId(
  153 |       `settings-user-row-${passwordTestAccount.email}`,
  154 |     );
  155 |     await expect(userRow).toBeVisible();
  156 |     await userRow.getByRole('button', { name: /Reset password/i }).click();
  157 |     await page
  158 |       .getByPlaceholder(/Minimum 8 characters, mixed/i)
  159 |       .fill(passwordTestAccount.temporaryPassword!);
  160 |     await page.getByRole('button', { name: /Confirm reset/i }).click();
  161 |     await expect(page.getByText(/Password reset/i)).toBeVisible();
  162 | 
  163 |     await clearBrowserSession(context, page);
  164 |     const forcedLogin = await login(page, {
  165 |       tenantSlug: schoolCredentials.tenantSlug!,
  166 |       email: passwordTestAccount.email!,
  167 |       password: passwordTestAccount.temporaryPassword!,
  168 |     });
  169 |     expect(forcedLogin.mustChangePassword).toBe(true);
  170 |     await expect(page).toHaveURL(
  171 |       /\/dashboard\/settings\/personal\/security(?:$|[?#])/,
  172 |     );
  173 | 
  174 |     await page
  175 |       .getByLabel(/^Current password$/i)
  176 |       .fill(passwordTestAccount.temporaryPassword!);
  177 |     await page
  178 |       .getByLabel(/^New password$/i)
  179 |       .fill(passwordTestAccount.finalPassword!);
  180 |     await page
  181 |       .getByLabel(/^Confirm new password$/i)
  182 |       .fill(passwordTestAccount.finalPassword!);
  183 |     await page.getByRole('button', { name: /^Change password$/i }).click();
  184 | 
  185 |     await expect(
  186 |       page.getByText(/Password changed successfully/i),
  187 |     ).toBeVisible();
  188 |   });
  189 | });
  190 | 
  191 | async function requireHealthyApi(page: Page) {
  192 |   try {
  193 |     const response = await page.request.get(`${API_BASE_URL}/health`);
  194 |     test.skip(!response.ok(), 'API is not healthy');
  195 |   } catch {
  196 |     test.skip(true, 'API is not reachable');
  197 |   }
  198 | }
  199 | 
  200 | async function clearBrowserSession(context: BrowserContext, page: Page) {
  201 |   await context.clearCookies();
  202 |   await page.goto('/login');
  203 |   await page.evaluate(() => {
  204 |     window.localStorage.clear();
  205 |     window.sessionStorage.clear();
  206 |   });
  207 | }
  208 | 
  209 | async function login(page: Page, credentials: Credentials) {
  210 |   await page.goto('/login');
  211 |   await expect(page.getByLabel(/School Code/i)).toBeVisible();
  212 |   await page.getByLabel(/School Code/i).fill(credentials.tenantSlug ?? '');
  213 |   await page.getByLabel(/Email/i).fill(credentials.email ?? '');
  214 |   await page.getByLabel(/^Password$/i).fill(credentials.password ?? '');
  215 | 
  216 |   await Promise.all([
  217 |     page.waitForURL(
  218 |       /\/(?:dashboard(?:\/settings\/personal\/security)?|platform(?:\/account-security)?)(?:$|[/?#])/,
  219 |       { timeout: 20_000 },
  220 |     ),
  221 |     page.getByRole('button', { name: /Sign in/i }).click(),
  222 |   ]);
  223 | 
  224 |   return {
  225 |     mustChangePassword:
  226 |       /\/(?:account-security|settings\/personal\/security)(?:$|[?#])/.test(
  227 |         page.url(),
  228 |       ),
```