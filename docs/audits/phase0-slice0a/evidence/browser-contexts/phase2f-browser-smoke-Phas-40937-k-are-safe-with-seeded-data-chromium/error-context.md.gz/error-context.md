# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: phase2f-browser-smoke.spec.ts >> Phase 2F.2 authenticated school admin browser smoke >> student directory filters and profile link are safe with seeded data
- Location: e2e/phase2f-browser-smoke.spec.ts:118:7

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('group', { name: /Directory filters/i })
Expected: visible
Timeout: 10000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 10000ms
  - waiting for getByRole('group', { name: /Directory filters/i })

```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - generic [ref=e2]:
    - main [ref=e3]:
      - region "SchoolOS could not verify access" [ref=e4]:
        - generic [ref=e5]:
          - img [ref=e7]
          - generic [ref=e9]:
            - paragraph [ref=e10]: Secure session check unavailable
            - heading "SchoolOS could not verify access" [level=1] [ref=e11]
        - paragraph [ref=e12]: SchoolOS reached the service, but the session check returned an unexpected response. Private school information stays hidden until a fresh check succeeds.
        - status [ref=e13]:
          - text: Retry the secure session check. If it keeps failing, contact the SchoolOS administrator with the time of the attempt.
          - paragraph [ref=e14]: Unsynced attendance drafts remain on this browser and have not been sent or deleted.
        - button "Check session securely" [ref=e15] [cursor=pointer]:
          - img [ref=e16]
          - text: Check session securely
    - region "Notifications alt+T"
  - alert [ref=e21]
```

# Test source

```ts
  24  |     process.env.SCHOOLOS_E2E_PLATFORM_PASSWORD ??
  25  |     (platformFixtureEnabled
  26  |       ? 'SchoolOS@2026'
  27  |       : process.env.PLATFORM_SEED_PASSWORD),
  28  | };
  29  | 
  30  | test.describe('Phase 2F.2 public browser smoke', () => {
  31  |   test.beforeEach(async ({ context }) => {
  32  |     await context.clearCookies();
  33  |     await context.clearPermissions();
  34  |   });
  35  | 
  36  |   test('loads the public home and login pages', async ({ page }) => {
  37  |     await page.goto('/');
  38  |     await expect(page).toHaveURL(/\/$/);
  39  |     await expect(page.getByRole('banner')).toContainText('SchoolOS');
  40  |     await expect(
  41  |       page.getByRole('banner').getByRole('link', { name: /^Sign in$/i }),
  42  |     ).toBeVisible();
  43  | 
  44  |     await page.goto('/login');
  45  |     await expect(page).toHaveURL(/\/login(?:$|[?#])/);
  46  |     await expect(page.getByLabel(/School Code/i)).toBeVisible();
  47  |     await expect(page.getByLabel(/Email/i)).toBeVisible();
  48  |   });
  49  | });
  50  | 
  51  | test.describe('Phase 2F.2 authenticated school admin browser smoke', () => {
  52  |   test.beforeEach(async ({ context, page }) => {
  53  |     test.skip(
  54  |       !schoolCredentials.tenantSlug ||
  55  |         !schoolCredentials.email ||
  56  |         !schoolCredentials.password,
  57  |       'Authenticated browser smoke requires seeded local API credentials.',
  58  |     );
  59  |     await context.clearCookies();
  60  |     await login(page, schoolCredentials);
  61  |   });
  62  | 
  63  |   test('loads polished daily school workflows without fatal pages', async ({
  64  |     page,
  65  |   }) => {
  66  |     const targets = [
  67  |       {
  68  |         // The dashboard home was redesigned around a "School Overview"
  69  |         // heading with backend-owned readiness sections; the old generic
  70  |         // "Dashboard/Quick Actions/Total Students" copy no longer appears.
  71  |         route: '/dashboard',
  72  |         visible: /School Overview|Needs your attention|Today.s operations/i,
  73  |       },
  74  |       { route: '/dashboard/students', visible: /Student Directory/i },
  75  |       {
  76  |         route: '/dashboard/admissions',
  77  |         visible: /Admissions|New admission|Applications Needing Review/i,
  78  |       },
  79  |       {
  80  |         route: '/dashboard/attendance',
  81  |         visible: /Attendance Roster|Smart Attendance/i,
  82  |       },
  83  |       {
  84  |         route: '/dashboard/fees/collect',
  85  |         visible: /Collect payment|Find student or invoice/i,
  86  |       },
  87  |       {
  88  |         route: '/dashboard/academics',
  89  |         visible: /Academics|Active Exam Terms|Workflow Readiness/i,
  90  |       },
  91  |       {
  92  |         route: '/dashboard/accounting',
  93  |         visible:
  94  |           /Fiscal Status|Financial Reporting Hub|Accounting access is restricted/i,
  95  |       },
  96  |       {
  97  |         route: '/dashboard/reports',
  98  |         visible: /Reports & Exports|Recent Exports|Module Locked/i,
  99  |       },
  100 |       {
  101 |         route: '/dashboard/settings',
  102 |         visible:
  103 |           /Choose a settings area|School setup status|Recent configuration changes/i,
  104 |       },
  105 |     ] as const;
  106 | 
  107 |     for (const target of targets) {
  108 |       await page.goto(target.route);
  109 |       await expect(
  110 |         page.locator('main').getByText(target.visible).first(),
  111 |       ).toBeVisible({
  112 |         timeout: 15_000,
  113 |       });
  114 |       await expectNoFatalPage(page, target.route);
  115 |     }
  116 |   });
  117 | 
  118 |   test('student directory filters and profile link are safe with seeded data', async ({
  119 |     page,
  120 |   }) => {
  121 |     await page.goto('/dashboard/students');
  122 |     await expect(
  123 |       page.getByRole('group', { name: /Directory filters/i }),
> 124 |     ).toBeVisible();
      |       ^ Error: expect(locator).toBeVisible() failed
  125 | 
  126 |     // Test search with real seeded data
  127 |     await page
  128 |       .getByLabel(
  129 |         /Search students by name, student code, guardian name, or phone/i,
  130 |       )
  131 |       .fill('STU001');
  132 |     await expect(page.locator('main')).toContainText(
  133 |       /Student Roster|No students found|STU001|S2024-001/i,
  134 |       { timeout: 10_000 },
  135 |     );
  136 | 
  137 |     // Test search with no results
  138 |     await page
  139 |       .getByLabel(
  140 |         /Search students by name, student code, guardian name, or phone/i,
  141 |       )
  142 |       .fill('NoSuchStudentForSmoke');
  143 |     await expect(
  144 |       page.getByText('No students match these filters', { exact: true }),
  145 |     ).toBeVisible();
  146 | 
  147 |     await page.getByRole('button', { name: 'Reset', exact: true }).click();
  148 | 
  149 |     const firstStudent = page
  150 |       .locator('a[href^="/dashboard/students/"]')
  151 |       .first();
  152 |     if (await firstStudent.isVisible()) {
  153 |       await firstStudent.click();
  154 |       await expect(page.locator('main h1').first()).toBeVisible();
  155 |       await expect(page.getByRole('button', { name: /Edit/i })).toBeVisible();
  156 |       await expect(
  157 |         page.getByRole('button', { name: /ID Card/i }),
  158 |       ).toBeVisible();
  159 |       await expect(page.getByRole('tab', { name: /Documents/i })).toBeVisible();
  160 |       await expect(page.getByRole('tab', { name: /History/i })).toBeVisible();
  161 |       await expect(page.getByText(/QR Identity|QR/i).first()).toBeVisible();
  162 |       await page.getByRole('tab', { name: /Documents/i }).click();
  163 |       await expect(page.getByText(/Document Audit Trail/i)).toBeVisible();
  164 |       await page.getByRole('button', { name: /Edit/i }).click();
  165 |       await expect(page.getByText(/Student Photo/i)).toBeVisible();
  166 |       await expect(
  167 |         page
  168 |           .getByText(/Upload|Replace/i)
  169 |           .or(page.getByText(/Remove/i))
  170 |           .first(),
  171 |       ).toBeVisible();
  172 |     }
  173 |   });
  174 | 
  175 |   test('attendance and admissions validation controls render', async ({
  176 |     page,
  177 |   }) => {
  178 |     await page.goto('/dashboard/attendance/mark');
  179 |     await expect(page.getByLabel(/^Class$/i)).toBeVisible();
  180 |     await expect(page.getByLabel(/^Date$/i)).toBeVisible();
  181 |     await expect(page.locator('main')).toContainText(
  182 |       /Smart Attendance|Attendance Roster|Expected Students/i,
  183 |     );
  184 | 
  185 |     await page.goto('/dashboard/admissions');
  186 |     await expect(
  187 |       page
  188 |         .locator('main')
  189 |         .getByRole('heading', { name: 'Admissions', exact: true }),
  190 |     ).toBeVisible();
  191 |     await page
  192 |       .locator('[data-schoolos-ui="module-header"]')
  193 |       .getByRole('link', { name: 'New admission', exact: true })
  194 |       .click();
  195 |     await expect(
  196 |       page.locator('main').getByRole('heading', { name: /New admission/i }),
  197 |     ).toBeVisible();
  198 |     await page
  199 |       .getByRole('button', {
  200 |         name: 'Start school-office admission',
  201 |         exact: true,
  202 |       })
  203 |       .click();
  204 |     await expect(
  205 |       page.getByRole('heading', { name: 'Student and guardian', exact: true }),
  206 |     ).toBeVisible();
  207 |     await page.getByRole('button', { name: 'Continue', exact: true }).click();
  208 |     await expect(
  209 |       page.getByText('Enter valid student names.', { exact: true }),
  210 |     ).toBeVisible();
  211 |   });
  212 | 
  213 |   test('platform routes are denied or redirected for a school user', async ({
  214 |     page,
  215 |   }) => {
  216 |     await page.goto('/platform/dashboard');
  217 |     await expectNoFatalPage(page, '/platform/dashboard');
  218 | 
  219 |     const platformUrl = page.url().includes('/platform');
  220 |     if (platformUrl) {
  221 |       await expect(
  222 |         page
  223 |           .locator('main')
  224 |           .getByText(
```